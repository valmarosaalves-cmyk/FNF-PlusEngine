/**
 * GlobalScript.hx - HScript Template
 * 
 * This script runs globally across all game states and persists throughout the entire game session.
 * Use this for game-wide functionality, utilities, or persistent data management.
 * 
 * Available Global Functions:
 * - setGlobalVar(name:String, value:Dynamic) - Set a global variable accessible from any state
 * - getGlobalVar(name:String, ?defaultValue:Dynamic) - Get a global variable value
 * - hasGlobalVar(name:String) - Check if a global variable exists
 * - removeGlobalVar(name:String) - Remove a global variable
 * 
 * - setStaticVar(name:String, value:Dynamic) - Set a static variable for this script
 * - getStaticVar(name:String, ?defaultValue:Dynamic) - Get a static variable value
 * 
 * - setPublicVar(name:String, value:Dynamic) - Set a public variable accessible from other scripts
 * - getPublicVar(name:String, ?defaultValue:Dynamic) - Get a public variable value
 */

/**
 * Called when the GlobalScript is first initialized
 * Use this to set up initial variables, register callbacks, or initialize systems
 */
function onCreate() {
    // Example: Set up global variables
    // setGlobalVar('myGlobalCounter', 0);
    
    trace('GlobalScript initialized!');
}

/**
 * Called every frame
 * 
 * @param elapsed - Time elapsed since last frame in seconds
 */
function onUpdate(elapsed:Float) {
    // Example: Update animations, timers, or continuous logic
    // trace('Delta time: ' + elapsed);
}

/**
 * Called every step (4 steps = 1 beat)
 * 
 * @param curStep - Current step number
 */
function onStepHit(curStep:Int) {
    // Example: Do something every 4 steps (every beat)
    // if (curStep % 4 == 0) {
    //     trace('Beat hit at step: ' + curStep);
    // }
}

/**
 * Called every beat (musical beat based on BPM)
 * 
 * @param curBeat - Current beat number
 */
function onBeatHit(curBeat:Int) {
    // Example: Do something every beat
    // trace('Beat: ' + curBeat);
}

/**
 * Called when a new section starts in the song
 * 
 * @param curSection - Current section number
 */
function onSectionHit(curSection:Int) {
    // Example: Track section changes
    // trace('Section: ' + curSection);
}

/**
 * Called when a fade-in transition starts
 * This happens when entering a new state with a transition
 */
function onFadeIn() {
    // Example: Prepare UI elements for fade in
    // trace('Fading in...');
}

/**
 * Called before switching to a different game state
 * 
 * @param nextState - Class name of the state being switched to (e.g., "PlayState", "MainMenuState")
 */
function onSwitchState(nextState:String) {
    // Example: Clean up resources or save data before switching
    // trace('Switching to: ' + nextState);
}

/**
 * Called before resetting the current state
 * This happens when the same state is reloaded (e.g., restarting a song)
 */
function onResetState() {
    // Example: Reset counters or clear temporary data
    // trace('Resetting state...');
}

/**
 * Called when a state transition animation starts
 * 
 * @param isReset - True if resetting the current state, false if switching to a new state
 * @param nextState - Class name of the next state (same as current if isReset is true)
 */
function onStartTransition(isReset:Bool, nextState:String) {
    // Example: Play transition sound or animation
    // if (isReset) {
    //     trace('Starting reset transition');
    // } else {
    //     trace('Starting transition to: ' + nextState);
    // }
}
