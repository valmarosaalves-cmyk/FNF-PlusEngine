--[[
    GlobalScript.lua - Lua Template
    
    This script runs globally across all game states and persists throughout the entire game session.
    Use this for game-wide functionality, utilities, or persistent data management.
    
    Available Global Functions:
    - setGlobalVar(name, value) - Set a global variable accessible from any state
    - getGlobalVar(name, defaultValue) - Get a global variable value
    - hasGlobalVar(name) - Check if a global variable exists
    - removeGlobalVar(name) - Remove a global variable
    
    Note: Lua GlobalScript is loaded first, then HScript GlobalScript
    Both can coexist and will both receive callbacks
--]]

--[[
    Called when the GlobalScript is first initialized
    Use this to set up initial variables, register callbacks, or initialize systems
--]]
function onCreate()
    -- Example: Set up global variables
    -- setProperty('globalCounter', 0)
    
    debugPrint('GlobalScript (Lua) initialized!')
end

--[[
    Called every frame
    
    @param elapsed - Time elapsed since last frame in seconds
--]]
function onUpdate(elapsed)
    -- Example: Update animations, timers, or continuous logic
    -- debugPrint('Delta time: ' .. elapsed)
end

--[[
    Called every step (4 steps = 1 beat)
    
    @param curStep - Current step number
--]]
function onStepHit()
    -- Example: Do something every 4 steps (every beat)
    -- if curStep % 4 == 0 then
    --     debugPrint('Beat hit at step: ' .. curStep)
    -- end
end

--[[
    Called every beat (musical beat based on BPM)
    
    Note: curBeat is available as a global variable
--]]
function onBeatHit()
    -- Example: Do something every beat
    -- debugPrint('Beat: ' .. curBeat)
end

--[[
    Called when a new section starts in the song
    
    Note: curSection is available as a global variable
--]]
function onSectionHit()
    -- Example: Track section changes
    -- debugPrint('Section: ' .. curSection)
end

--[[
    Called when a fade-in transition starts
    This happens when entering a new state with a transition
--]]
function onFadeIn()
    -- Example: Prepare UI elements for fade in
    -- debugPrint('Fading in...')
end

--[[
    Called before switching to a different game state
    
    @param nextState - Class name of the state being switched to (e.g., "PlayState", "MainMenuState")
--]]
function onSwitchState(nextState)
    -- Example: Clean up resources or save data before switching
    -- debugPrint('Switching to: ' .. nextState)
end

--[[
    Called before resetting the current state
    This happens when the same state is reloaded (e.g., restarting a song)
--]]
function onResetState()
    -- Example: Reset counters or clear temporary data
    -- debugPrint('Resetting state...')
end

--[[
    Called when a state transition animation starts
    
    @param isReset - true if resetting the current state, false if switching to a new state
    @param nextState - Class name of the next state (same as current if isReset is true)
--]]
function onStartTransition(isReset, nextState)
    -- Example: Play transition sound or animation
    -- if isReset then
    --     debugPrint('Starting reset transition')
    -- else
    --     debugPrint('Starting transition to: ' .. nextState)
    -- end
end
