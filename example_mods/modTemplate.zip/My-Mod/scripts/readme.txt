Add global scripts here!

Scripts in this folder (.lua, .hx) will run everywhere - on all songs.

For state-specific scripts, use the "states/" subfolder.
For global scripts, your should create the "GlobalScript" file here.
For song-specific scripts, put them in "songs/[song-name]/script.lua" or "script.hx".